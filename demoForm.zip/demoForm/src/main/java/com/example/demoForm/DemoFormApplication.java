package com.example.demoForm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoFormApplication.class, args);
	}

}
